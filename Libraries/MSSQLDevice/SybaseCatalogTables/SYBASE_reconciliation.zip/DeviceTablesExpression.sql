select
    convert(varchar(128), su.name) as TableSchema,
    convert(varchar(128), so.name) as TableName,
    convert(varchar(128), sc.name) as ColumnName,
    sc.colid as OrdinalPosition,
    convert(varchar(128), so.name) TableTitle,
    convert(varchar(128), sc.name) ColumnTitle,
    convert(varchar(128), sut.name) DomainName,
    convert(integer, sc.length) as Length,
    (sc.status / 8) % 2 as IsNullable,
    case when sut.name in ('text', 'image') then 1 else 0 end as IsDeferred
from sysobjects as so
join sysusers as su
  on so.uid = su.uid
join syscolumns as sc
  on so.id = sc.id
join systypes as sut
  on sc.usertype = sut.usertype
where (so.type = 'U' or so.type = 'V')
order by TableName, OrdinalPosition
