select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    1 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 1) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 1)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    2 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 2) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 2)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    3 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 3) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 3)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    4 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 4) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 4)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    5 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 5) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 5)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    6 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 6) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 6)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    7 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 7) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 7)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    8 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 8) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 8)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    9 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 9) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 9)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    10 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 10) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 10)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    11 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 11) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 11)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    12 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 12) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 12)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    13 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 13) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 13)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    14 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 14) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 14)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    15 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 15) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 15)
union
select
    su.name as TableSchema,
    so.name as TableName,
    si.name as IndexName,
    sc.name as ColumnName,
    16 OrdinalPosition,
    (si.status / 2) % 2 as IsUnique,
    case
        when index_colorder(so.name, si.indid, 16) = 'DESC' then 1
        else 0
    end IsDescending
from sysobjects as so
join sysusers as su on so.uid = su.uid
join sysindexes as si on si.id = so.id
join syscolumns sc
  on so.id = sc.id
where (so.type = 'U' or so.type = 'V')
  and sc.name = index_col(so.name, si.indid, 16)
order by TableSchema, TableName, IndexName, OrdinalPosition
