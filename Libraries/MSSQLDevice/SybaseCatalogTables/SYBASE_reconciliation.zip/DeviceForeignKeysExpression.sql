select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    1 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey1 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey1 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    2 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey2 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey2 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    3 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey3 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey3 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    4 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey4 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey4 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    5 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey5 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey5 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    6 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey6 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey6 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    7 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey7 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey7 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    8 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey8 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey8 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    9 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey9 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey9 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    10 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey10 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey10 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    11 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey11 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey11 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    12 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey12 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey12 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    13 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey13 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey13 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    14 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey14 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey14 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    15 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey15 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey15 = sct.colid
union
select
    convert(varchar(128), suc.name) ConstraintSchema,
    convert(varchar(128), soc.name) ConstraintName,
    convert(varchar(128), sus.name) SourceTableSchema,
    convert(varchar(128), sos.name) SourceTableName,
    convert(varchar(128), scs.name) SourceColumnName,
    convert(varchar(128), sut.name) TargetTableSchema,
    convert(varchar(128), sot.name) TargetTableName,
    convert(varchar(128), sct.name) TargetColumnName,
    16 OrdinalPosition
from sysreferences sr
join sysobjects soc
  on sr.constrid = soc.id
join sysusers suc
  on soc.uid = suc.uid
join sysobjects sos
  on sr.tableid = sos.id
join sysusers sus
  on sos.uid = sus.uid
join syscolumns scs
  on sos.id = scs.id
 and sr.fokey16 = scs.colid
join sysobjects sot
  on sr.reftabid = sot.id
join sysusers sut
  on sot.uid = sut.uid
join syscolumns sct
  on sot.id = sct.id
 and sr.refkey16 = sct.colid
order by ConstraintSchema, ConstraintName, OrdinalPosition
